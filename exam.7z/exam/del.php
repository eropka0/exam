<?php
$name=$_POST['name'];
$sql= new mysqli('127.0.0.1','root','','DB','3306');
$result = $sql->query("DELETE FROM events WHERE name = '$name'");
$sql->close();
header('Location: hello.php');
?>