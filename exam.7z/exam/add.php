<?php
$name = $_POST['name'];
$date = $_POST['date'];
$description = $_POST['description'];
$organizer = $_POST['organizer'];
$sql = new mysqli('127.0.0.1', 'root', '', 'DB', 3306);
$sql->query("INSERT INTO events (`name`, `date`, `description`, `organizer`, `user_id`) VALUES ('$name', '$date', '$description', '$organizer', 1)");
header('Location: hello.php');
$sql->close();
?>
