<?php
$sql = new mysqli('127.0.0.1', 'root', '', 'DB', '3306');
$result = $sql->query("SELECT * FROM `events`");
$data = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <title>События университета</title>
  <style>
    html, body {
      font-family: 'Roboto', Arial, sans-serif;
      color: #333;
      display: flex;
      justify-content: center;
      background-color: #f0f0f0; /* Фон страницы */
      padding-top: 20px;
    }

    .container {
      max-width: 1200px;
      padding: 30px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    }

    h1 {
      font-size: 2.5em;
      color: #e63946;
      margin-bottom: 30px;
      text-align: center;
    }

    .card {
      border: none;
      border-radius: 10px;
      background-color: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    }

    .card-body {
      padding: 20px;
    }

    .card-title {
      font-size: 1.8em;
      font-weight: bold;
      color: #333;
    }

    .card-text {
      font-size: 1.1em;
      color: #666;
      margin-bottom: 10px;
    }

    .date {
      font-weight: bold;
      color: #4CAF50;
    }

    .organizer {
      font-weight: bold;
      color: #e63946;
    }

    .row {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }

    .col-md-4 {
      max-width: 350px;
      flex: 1 0 30%;
    }

    .add-form, .delete-form {
      margin-top: 40px;
    }

    .add-form input, .delete-form input {
      width: 100%;
      margin-bottom: 15px;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ddd;
    }

    .btn {
      border-radius: 8px;
      font-weight: bold;
      padding: 12px;
      width: 100%;
    }

    .btn-success {
      background-color: #28a745;
      color: white;
    }

    .btn-danger {
      background-color: #dc3545;
      color: white;
    }
  </style>
</head>
<body>

<div class="container">
    <h1>События университета</h1>
    
    <div class="row">
        <?php foreach ($data as $event): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($event['name']); ?></h5>
                        <p class="card-text date"><?php echo htmlspecialchars($event['date']); ?></p>
                        <p class="card-text"><?php echo htmlspecialchars($event['description']); ?></p>
                        <p class="card-text organizer">Организатор: <?php echo htmlspecialchars($event['organizer']); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Форма добавления товара -->
    <div class="add-form">
    <h2>Добавить товар</h2>
    <form action="add.php" method="post" enctype="multipart/form-data">
        <input type="text" name="name" class="form-control mb-2" placeholder="Название события" required>
        <input type="text" name="date" class="form-control mb-2" placeholder="Дата" required>
        <input type="text" name="description" class="form-control mb-2" placeholder="Описание" required>
        <input type="text" name="organizer" class="form-control mb-2" placeholder="Организатор" required>
        <button class="btn btn-success">Добавить</button>
    </form>
</div>

    <!-- Форма удаления товара -->
    <div class="delete-form">
        <h2>Удалить Событие</h2>
        <form action="del.php" method="post">
            <input type="text" name="ID" class="form-control mb-2" placeholder="Название События" required>
            <button class="btn btn-danger">Удалить</button>
        </form>
    </div>
</div>

</body>
</html>
