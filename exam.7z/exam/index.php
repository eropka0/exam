<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <title>exam</title>
  <style>
html, body {
  margin: 0;
  padding: 0;
  height: 100%;
  font-family: 'Roboto', Arial, sans-serif;
  color: #333;
  display: flex;
  justify-content: center;
  align-items: center;
}

.container {
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
  max-width: 400px;
  width: 100%;
  text-align: center;
}

h1 {
  font-size: 2em;
  color: #4a4a4a;
  margin-bottom: 20px;
}

input[type="text"],
input[type="password"] {
  width: 100%;
  padding: 12px;
  margin-bottom: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1em;
  box-sizing: border-box;
  background: #f9f9f9;
  transition: border-color 0.3s;
}

input[type="text"]:focus,
input[type="password"]:focus {
  border-color: #acb6e5;
  outline: none;
}

button {
  width: 100%;
  padding: 12px;
  background-color: #e63946;
  border: none;
  border-radius: 8px;
  color: white;
  font-size: 1em;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s, transform 0.2s;
}

button:hover {
  background-color: #d62839;
  transform: scale(1.05);
}

button:active {
  transform: scale(0.98);
}

a {
  color: #e63946;
  text-decoration: none;
  font-weight: bold;
}
.logo {
      position: absolute;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      width: 100px;
      height: auto;
    }

a:hover {
  text-decoration: underline;
}
  </style>
</head>
<body>
<img src="logo.png" class="logo">
  <div class="container mt-4">
    <div class="row">
      <div class="col">
        <div class="center">
         <h1>Форма авторизации</h1>
           <form action="auth.php" method="post">
            <input type="text" name="login" class="form-control" id="login" placeholder="Логин"><br>
            <input type="password" name="pass" class="form-control" id="pass" placeholder="Пароль"><br>
            <button class="btn btn-success">Авторизоваться</button><br>
          </form> 
        </div>
      </div>
    </div>
  </div>
</body>
</html>
