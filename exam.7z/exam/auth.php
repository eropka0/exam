<?php
$login=$_POST['login'];
$pass=$_POST['pass'];
$sql= new mysqli('127.0.0.1','root','','DB','3306');
$result = $sql->query("SELECT * FROM authorization WHERE Login='$login' AND Password= '$pass'");
$data = $result->fetch_assoc();
if(empty($data))
{
echo "Введен неверный логин или пароль";
}
else
{
$sql->close();
header('Location: hello.php');
}